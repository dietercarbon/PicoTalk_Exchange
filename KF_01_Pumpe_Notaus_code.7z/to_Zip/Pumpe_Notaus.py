"""
A pump, operated by 230V AC power, circulates a liquid from a canister in a closed loop.

To prevent the pump from running dry,
it should be shut off when the liquid level falls below a certain point,
for example, if a hose bursts.
Additionally, an SMS notification should be sent.

Components used:

- Microcontroller:		Raspberry Pi Pico WH
- Switchable socket:	Olimex Switchable Socket 230V 16A for Arduino, ESP32, and Raspberry Pi PWR-SWITCH (Article No.: RBS15731), https://www.roboter-bausatz.de/p/olimex-schaltsteckdose-230v-16a-fuer-arduino-esp32-und-raspberry-pi-pwr-switch
- Level sensor:			Float switch, Level sensor Contactless NPN output interface IP67 Waterproof XKC-Y25-NPN 5-12V, https://www.amazon.de/Schwimmerschalter-Füllstandssensor-Berührungslose-NPN-Ausgangsschnittstelle-Wasserdicht/dp/B09BL5SS3H/ref=sr_1_1?__mk_de_DE=ÅMÅŽÕÑ&crid=36U85TFL7I318&dib=eyJ2IjoiMSJ9.MxYoQa_BVS5ip8NFLzwT0A.5pOtJnMSY_ty7miBfdVs7CC4G7h4hQc5TRNfacyeGZM&dib_tag=se&keywords=B09BL5SS3H&nsdOptOutParam=true&qid=1736254750&sprefix=b09bl5ss3h%2Caps%2C90&sr=8-1

Code used:

- Switchable socket:	Manual:			https://www.roboter-bausatz.de/media/pdf/b6/04/27/PWR-SWITCH.pdf
                                        User manual code translated to MicroPython with Perplexity 
- Level sensor:			https://forums.raspberrypi.com/viewtopic.php?t=349713
                        Manual:			https://xkc-sensor.com/upload/1686717723.pdf
                        Youtube video:	https://www.youtube.com/watch?v=g50WgU8ylk0
- Sending WhatsApp:		https://microcontrollerslab.com/send-messages-whatsapp-raspberry-pi-pico-w/
                        services used:	https://www.callmebot.com/
                                        https://www.callmebot.com/blog/free-api-whatsapp-messages/
                                        (https://whatabot.io/)
                                        

Raspberry Pi Pico Power specifications:
(https://penguintutor.com/electronics/pico-power)
The following information about the power requirements for the
Raspberry Pi Pico is taken from the Raspberry Pi Pico datasheet:
(https://datasheets.raspberrypi.com/pico/pico-datasheet.pdf)

VSYS: 1.8 to 5.5V
VBUS: 5V ±10%
Current used: 18mA to 95mA (approx)*
Max output 3.3V: 300mA

* The actual power used by the Pico varies depending upon a number of factors.
The 18mA is based on running a simple blink program,
the top value is based on Popcorn video playback through a VGA adapter board.
The adapter board is included in the current value.
"""


# imports
from machine import Pin
from time import sleep
from wlan_access import WlanSSID, WlanPW, ApiKey
from NTP_RTC import setTimeRTC
from callmebot import send_whatsapp_message

#constants
ssid = WlanSSID()
password = WlanPW()
counter = 0 

phone_number_Api_Key = ApiKey()

# initializations
pwr_switch = Pin(17, Pin.OUT, value=0) # Main power switch
sensor_1 = Pin(28, Pin.IN, Pin.PULL_UP) # upper level
sensor_2 = Pin(1, Pin.IN, Pin.PULL_UP) # lower level
setTimeRTC()

# main power switch
def MainSwitchOn():
    """Truns Olimex on"""  
    pwr_switch.value(1)  # Turn on the switch
    sleep(1)        # Wait for 1 second

def MainSwitchOff():
    """Truns Olimex off"""
    pwr_switch.value(0)  # Turn off the switch
    sleep(0.01)     # Wait for 10 milliseconds
    


# level sensor
def sensor():
    """Reads out the two capacitive level sensors and returns the values as a tuple"""
    # read the sensor pin states
    upper_liquid_level = sensor_1.value()
    lower_liquid_level = sensor_2.value()
    
    # return the liquid levels as a Boolean values
    return (bool(upper_liquid_level), bool(lower_liquid_level))


# main program

try:
    MainSwitchOn()
    message = 'Pumpe eingeschaltet.'
    print(message)
    send_whatsapp_message(WlanSSID(), WlanPW(), phone_number_Api_Key, message)
    while True:
        upper, lower = sensor()
        if upper == False and lower == False:
            MainSwitchOff()
            message = 'Warnung!\nBeide Fuellstaende wurde unterschritten.\nDie Pumpe wurde ausgeschaltet.'
            print(message)
            send_whatsapp_message(WlanSSID(), WlanPW(), phone_number_Api_Key, message)
            break
        elif counter == 0 and upper == False:
            counter +=1
            message = 'WARNUNG!\nOberer Fuellstand wurde unterschritten.'
            print(message)
            send_whatsapp_message(WlanSSID(), WlanPW(), phone_number_Api_Key, message)
        elif counter == 1 and lower == False:
            MainSwitchOff()
            message = 'ALARM!\nUnterer Fuellstand wurde unterschritten.\nDie Pumpe wurde ausgeschaltet.'
            print(message)
            send_whatsapp_message(WlanSSID(), WlanPW(), phone_number_Api_Key, message)
            break
        sleep(1)
            
            
except KeyboardInterrupt:
    MainSwitchOff()
    Pin('LED', Pin.OUT, value=0)
    pass

finally:
    MainSwitchOff()
    Pin('LED', Pin.OUT, value=0)
    print("Programm beendet")



