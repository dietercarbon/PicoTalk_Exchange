import urequests
import network
import gc
from machine import RTC, Pin

network.country('DE')
station = network.WLAN(network.STA_IF)
# Status-LED
led_onboard = Pin('LED', Pin.OUT, value=0)

def is_ascii(s):
    return (ord(s) > 33) and ( ord(s) < 128) 

    # Encode the text
def urlencode(text):
    #data = urlencoded_text.encode()
    encoded_text = ""
    for char in text:
        if (is_ascii(char)) or char in "-_.~":
            encoded_text += char
            #print("if")
        else:
            encoded_text += "%{:02x}".format(ord(char))
            #print("else")
    print(encoded_text)
    return encoded_text

def connect_wifi(ssid, password):
    station.active(True)
    station.connect(ssid, password)
    while station.isconnected() == False:
        pass
    print('Connection successful')
    led_onboard.on()
    print(station.ifconfig())

def send_whatsapp_message(ssid, password, phone_number_api_key, message):
    connect_wifi(ssid, password)
    timestamp = ' ({:02d}.{:02d}.{}_{:02d}:{:02d}:{:02d}_GMT)'.format(
        RTC().datetime()[2],
        RTC().datetime()[1],
        RTC().datetime()[0],
        RTC().datetime()[4],
        RTC().datetime()[5],
        RTC().datetime()[6])
    message = message + timestamp
    
    for recipient in phone_number_api_key:
        phone_number = recipient[1]
        api_key = recipient[2]
        url = 'https://api.callmebot.com/whatsapp.php?phone='+phone_number+'&text='+str(urlencode(message))+'&apikey='+api_key

        response = urequests.get(url)
        if response.status_code == 200:
            print('Successfully sent to {}'.format(phone_number))
        else:
            print('Error while sending to {}'.format(phone_number))
            print(response.text)
    # WLAN-Verbindung trennen
    station.disconnect()
    # WLAN-Interface deaktivieren
    station.active(False)
    led_onboard.off()
    print('WLAN-Verbindung beendet')

    