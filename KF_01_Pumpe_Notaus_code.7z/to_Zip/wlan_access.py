def WlanSSID():
    wlanSSID_value = "Vodafone-xyz" # Hier der Name des drahtlosen Netzwerkes (WLANs)
    return wlanSSID_value

def WlanPW():
    wlanPW_value = "grekq2l4545fvre1" # Hier das Passwort des drahtlosen Netzwerkes (WLANs)
    return wlanPW_value

def ApiKey():
    # Der Anleitung folgen: https://www.callmebot.com/blog/free-api-whatsapp-messages/
    # Man erstellt einen neuen Kontakt in Whatsapp (z.B. mit dem Namen: CallMeBot),
    # welcher folgende Telefonnummer hat: 0034 621 062 163
    # Dann sedndet man folgende Nachricht per WhatsApp: I allow callmebot to send me messages
    # Nach kurzer Zeit erhält man eine Nachricht per WhatsApp, die in etwa so aussieht:
    """
CallMeBot API *Activated* for 4915434523876			Das ist die eigen Telefonnummer			
    Your apikey is: *5423486*		Und das der zugehörige API-Key			
    
    You can now send messages using the API.
    https://api.callmebot.com/whatsapp.php?phone=4915434523876&text=This+is+a+test&apikey=5423486
    
    Send *Stop* to pause the Bot.
    Send *Resume* to enable it again.
    """
    
    Phone_number = '491543452387'
    ApiKey_value = '5423486'
    return [[Phone_number, ApiKey_value]]

